# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.

import dataSampling.f_random
import dataSampling

import decorator.decorate
import decorator

import Factory.factory
import Factory

def homework1():
    result = dataSampling.f_random.get_random(((1, 100), int), ((0.0, 100.0), float), ((8, 10), str),
                                     (((2022103000, 2022103999), (6, 15)), tuple), (((2, 6), int), list),
                                     (((2, 6), str), list))
    num = len(result)
    print("随机产生的随机数如下：")
    for i in range(num):
        print(result[i])

def homework2():
    ob=dataSampling.f_random.get_random(((1, 100), int))
    str1=["svm","rf","cnn","rnn"]
    str2=["acc","mcc","f1","recall"]
    ##print(ob)
    for s1 in str1:
        for s2 in str2:
            print("随机值:", ob, ";  修饰器:", s1," ",s2)
            decorator.decorate.solve(s1,s2,ob)

def homework3():
    ob = dataSampling.f_random.get_random(((1, 100), int))
    str1 = ["svm", "rf", "cnn", "rnn"]
    str2 = ["acc", "mcc", "f1", "recall"]
    ##print(ob)
    for s1 in str1:
        for s2 in str2:
            print("随机值:", ob, ";  修饰器:", s1, " ", s2)
            Factory.factory.solve(s1, s2, ob)

# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    print("展示作业1：")
    homework1()
    # while 1:
    #     print("请输入选项（1,2,3）：")
    #     op = int(input())
    #     if (op == 1):
    #         homework1()
    #     elif (op == 2):
    #         homework2()
    #     else:
    #         homework3()

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
